﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootMeUp.Model
{
    /// <summary>
    /// A basic Coordinate frame system
    /// </summary>
    public class CFrame
    {
        public int X;
        public int Y;

        public int length;
        public int height;


        public CFrame(int X, int Y, int length, int height) 
        {
            this.X = X;
            this.Y = Y;
            this.length = length;
            this.height = height;
        }

        public override string ToString()
        {
            return $"{{{X},{Y}}},{{{length},{height}}}";
        }
    }
}
