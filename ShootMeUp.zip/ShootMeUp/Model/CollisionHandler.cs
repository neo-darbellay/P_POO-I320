﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootMeUp.Model
{
    /// <summary>
    /// This class is used to run checks to see if two objects would collide in a 2d environment
    /// </summary>
    public class CollisionHandler
    {
        /// <summary>
        /// The list of all the obstacles
        /// </summary>
        private static List<Obstacle> _lst_Obstacles = new List<Obstacle>();

        /// <summary>
        /// The list of all the obstacles
        /// </summary>
        public List<Obstacle> Obstacles { get { return _lst_Obstacles; } }

        public CollisionHandler() { }

        /// <summary>
        /// Add a new obstacle to the list
        /// </summary>
        /// <param name="NewObstacle">The obstacle to add</param>
        public void AddObstacle(Obstacle NewObstacle)
        {
            _lst_Obstacles.Add(NewObstacle);
        }

        /// <summary>
        /// Checks if the given coordinate frame of an object would colide with an obstacle's
        /// </summary>
        /// <param name="Coordinates">The coordinate frame of an object</param>
        /// <returns>A bool table, where index 0 is the X axis, and index 1 is the Y axis. </returns>
        public bool[] CheckForCollisions(CFrame Coordinates)
        {
            bool[] blnColliding = new bool[2] {false, false};

            // Check if any of the obstacles in the list overlap with the given CFrame
            foreach (Obstacle obstacle in _lst_Obstacles)
            {
                bool blnOverlapX = Coordinates.X < obstacle.X + obstacle.length && Coordinates.X + Coordinates.length > obstacle.X;
                bool blnOverlapY = Coordinates.Y < obstacle.Y + obstacle.height && Coordinates.Y + Coordinates.height > obstacle.Y;


                // Collision(s) detected
                if (blnOverlapX)
                {
                    blnColliding[0] = true; 
                }

                if (blnOverlapY)
                {
                    blnColliding[1] = true;
                }
            }

            return blnColliding;
        }
    }
}
