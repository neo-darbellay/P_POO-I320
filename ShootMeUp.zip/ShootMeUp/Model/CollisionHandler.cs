﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootMeUp.Model
{
    /// <summary>
    /// This class is used to run checks to see if two objects would collide in a 2d environment
    /// </summary>
    public class CollisionHandler
    {
        /// <summary>
        /// The list of all the obstacles
        /// </summary>
        private static List<Obstacle> _lst_Obstacles = new List<Obstacle>();

        /// <summary>
        /// The list of all the obstacles
        /// </summary>
        public List<Obstacle> Obstacles { get { return _lst_Obstacles; } }

        public CollisionHandler() { }

        /// <summary>
        /// Add a new obstacle to the list
        /// </summary>
        /// <param name="NewObstacle">The obstacle to add</param>
        public void AddObstacle(Obstacle NewObstacle)
        {
            _lst_Obstacles.Add(NewObstacle);
        }

        /// <summary>
        /// Checks if the given coordinate frame of an object would colide with an obstacle's
        /// </summary>
        /// <param name="Coordinates">The coordinate frame of an object</param>
        /// <param name="intXMovement">The movement that will happen in the X axis</param>
        /// <param name="intYMovement">The movement that will happen in the Y axis</param>
        /// <returns>A bool table, where index 0 is the X axis, and index 1 is the Y axis. </returns>
        public bool[] CheckForCollisions(CFrame Coordinates, int intXMovement, int intYMovement)
        {
            bool[] blnColliding = new bool[2] { false, false };

            // Create hypothetical CFrames to simulate movement along each axis independently
            CFrame cfrX = new CFrame(Coordinates.X + intXMovement, Coordinates.Y, Coordinates.length, Coordinates.height);
            CFrame cfrY = new CFrame(Coordinates.X, Coordinates.Y + intYMovement, Coordinates.length, Coordinates.height);

            foreach (Obstacle obstacle in _lst_Obstacles)
            {
                if (IsOverlapping(cfrX, obstacle))
                {
                    blnColliding[0] = true; // Collision if moved along X axis
                }

                if (IsOverlapping(cfrY, obstacle))
                {
                    blnColliding[1] = true; // Collision if moved along Y axis
                }

                // Early exit if both collisions detected
                if (blnColliding[0] && blnColliding[1])
                    break;
            }

            return blnColliding;
        }

        // Helper method to check if two CFrames overlap
        private bool IsOverlapping(CFrame a, CFrame b)
        {
            bool overlapX = a.X < b.X + b.length && a.X + a.length > b.X;
            bool overlapY = a.Y < b.Y + b.height && a.Y + a.height > b.Y;
            return overlapX && overlapY;
        }







        //OLD VERSION
        //public bool[] CheckForCollisions(CFrame Coordinates, int intXMovement, int intYMovement)
        //{
        //    bool[] blnColliding = new bool[2] {false, false};

        //    // Check if any of the obstacles in the list overlap with the given CFrame
        //    foreach (Obstacle obstacle in _lst_Obstacles)
        //    {
        //        bool blnOverlapX = Coordinates.X < obstacle.X + obstacle.length && Coordinates.X + Coordinates.length > obstacle.X;
        //        bool blnOverlapY = Coordinates.Y < obstacle.Y + obstacle.height && Coordinates.Y + Coordinates.height > obstacle.Y;


        //        // Collision(s) detected
        //        if (blnOverlapX)
        //        {
        //            blnColliding[0] = true; 
        //        }

        //        if (blnOverlapY)
        //        {
        //            blnColliding[1] = true;
        //        }
        //    }

        //    return blnColliding;
        //}
    }
}
