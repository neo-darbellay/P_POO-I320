using ShootMeUp.Model;

namespace ShootMeUp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // D�marrage
            Application.Run(new ShootMeUp(new Character(ShootMeUp.WIDTH / 2 - 32, ShootMeUp.HEIGHT / 2 - 32, 64, 64)));
        }
    }
}