using ShootMeUp.Model;

namespace ShootMeUp
{
    /// <summary>
    /// The ShootMeUp class is used to serve as a 2D playspace for the player and enemies.
    /// </summary>
    public partial class ShootMeUp : Form
    {
        /// <summary>
        /// Width of the game area
        /// </summary>
        public static readonly int WIDTH = 576;
        
        /// <summary>
        /// Height of the game area
        /// </summary>
        public static readonly int HEIGHT = 576;

        /// <summary>
        /// The player
        /// </summary>
        private Character _player;

        private CollisionHandler _collisionHandler;

        public static readonly int GAMESPEED = 4;

        BufferedGraphicsContext currentContext;
        BufferedGraphics playspace;

        // Initialisation de l'espace a�rien avec un certain nombre de drones
        public ShootMeUp(Character player)
        {
            InitializeComponent();
            ClientSize = new Size(WIDTH, HEIGHT);


            // Gets a reference to the current BufferedGraphicsContext
            currentContext = BufferedGraphicsManager.Current;

            // Creates a BufferedGraphics instance associated with this form, and with
            // dimensions the same size as the drawing surface of the form.
            playspace = currentContext.Allocate(this.CreateGraphics(), this.DisplayRectangle);
            _player = player;

            // Create a new CollisionHandler
            _collisionHandler = new CollisionHandler();

            // Create two new temporary obstacles
            Obstacle TEST1 = new Obstacle(150, 100, 64, 64, 0);
            Obstacle TEST2 = new Obstacle(150, 250, 64, 64, 4);

            _collisionHandler.AddObstacle(TEST1);
            _collisionHandler.AddObstacle(TEST2);

        }

        /// <summary>
        /// Render the playspace along with the player
        /// </summary>
        private void Render()
        {
            playspace.Graphics.Clear(Color.FromArgb(217, 217, 217));

            playspace.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(250, 231, 172)), new Rectangle(64, 64, 464, 464));
            playspace.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.FromArgb(0, 0, 0)), 8), new Rectangle(60, 60, 472, 472));

            _player.Render(playspace);

            // Get the obstacles
            List<Obstacle> Obstacles = _collisionHandler.Obstacles;

            // Loop through all of them and render them
            foreach (Obstacle obstacle in Obstacles)
            {
                obstacle.Render(playspace);
            }

            playspace.Render();
        }

        // Calcul du nouvel �tat apr�s que 'interval' millisecondes se sont �coul�es
        private void Update(int interval)
        {
            _player.Update(interval);
        }

        // M�thode appel�e � chaque frame
        private void NewFrame(object sender, EventArgs e)
        {
            this.Update(ticker.Interval);
            this.Render();
        }

        private void AirSpace_KeyDown(object sender, KeyEventArgs e)
        {
            /*
                Q W E
                A S D
                Y X C

                S to shoot

                Q/E/Y/C for diagonal movement (would need some math formula)

                A/W/D/X for normal movement
              
            */

            switch (e.KeyCode)
            {
                case Keys.W:
                case Keys.Up:
                    _player.Move(0, -1 * GAMESPEED);

                    break;

                case Keys.S:
                case Keys.Down:
                    _player.Move(0, 1 * GAMESPEED);

                    break;

                case Keys.A:
                case Keys.Left:
                    _player.Move(-1 * GAMESPEED, 0);

                    break;

                case Keys.D:
                case Keys.Right:
                    _player.Move(1 * GAMESPEED, 0);

                    break;
            }
        }

        private void AirSpace_Load(object sender, EventArgs e)
        {

        }
    }
}