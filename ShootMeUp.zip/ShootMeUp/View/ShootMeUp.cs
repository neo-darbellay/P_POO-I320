using ShootMeUp.Model;
using System.Drawing;

namespace ShootMeUp
{
    /// <summary>
    /// The ShootMeUp class is used to serve as a 2D playspace for the player and enemies.
    /// </summary>
    public partial class ShootMeUp : Form
    {
        /// <summary>
        /// Width of the game area
        /// </summary>
        public static readonly int WIDTH = 608;
        
        /// <summary>
        /// Height of the game area
        /// </summary>
        public static readonly int HEIGHT = 608;

        /// <summary>
        /// The player
        /// </summary>
        private Character _player;

        /// <summary>
        /// The list of keys currently held down
        /// </summary>
        private List<Keys> _lst_keysHeldDown;

        /// <summary>
        /// A collision handler to create obstacles
        /// </summary>
        private CollisionHandler _collisionHandler;

        /// <summary>
        /// The game's speed multiplier (movement, 
        /// </summary>
        public static readonly int GAMESPEED = 2;

        BufferedGraphicsContext currentContext;
        BufferedGraphics playspace;

        // Initialisation de l'espace a�rien avec un certain nombre de drones
        public ShootMeUp(Character player)
        {
            InitializeComponent();
            ClientSize = new Size(WIDTH, HEIGHT);


            // Gets a reference to the current BufferedGraphicsContext
            currentContext = BufferedGraphicsManager.Current;

            // Creates a BufferedGraphics instance associated with this form, and with
            // dimensions the same size as the drawing surface of the form.
            playspace = currentContext.Allocate(this.CreateGraphics(), this.DisplayRectangle);
            _player = player;

            // Create a new list of keys held down
            _lst_keysHeldDown = new List<Keys>();

            // Create a new CollisionHandler
            _collisionHandler = new CollisionHandler();

            // Define the play area size in increments of 32
            int intBorderSize = 16;

            // Create a new border
            for (int x = 0; x <= intBorderSize; x++)
            {
                for (int y = 0; y <= intBorderSize; y++)
                {
                    if (x == 0 || x == intBorderSize || y == 0 || y == intBorderSize)
                    {
                        // Create a border piece
                        Obstacle obsBorder = new Obstacle(32 * (1 + x), 32 * (1 + y), 32, 32, 0, "border");


                        // Add the border piece to the collision handler
                        _collisionHandler.AddObstacle(obsBorder);
                    }
                }
            }



            // Create two new temporary obstacles
            Obstacle TEST1 = new Obstacle(150, 100, 64, 64, 0, "default");
            Obstacle TEST2 = new Obstacle(150, 250, 64, 64, 4, "default");

            _collisionHandler.AddObstacle(TEST1);
            _collisionHandler.AddObstacle(TEST2);

        }

        /// <summary>
        /// Render the playspace along with the player
        /// </summary>
        private void Render()
        {
            playspace.Graphics.Clear(Color.FromArgb(217, 217, 217));

            playspace.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(250, 231, 172)), new Rectangle(64, 64, 510, 510));

            _player.Render(playspace);

            // Get the obstacles
            List<Obstacle> Obstacles = _collisionHandler.Obstacles;

            // Loop through all of them and render them
            foreach (Obstacle obstacle in Obstacles)
            {
                obstacle.Render(playspace);
            }

            playspace.Render();
        }

        // Calcul du nouvel �tat apr�s que 'interval' millisecondes se sont �coul�es
        private void Update(int interval)
        {
            // Create movement-related boolean variables
            bool blnLeftHeld = _lst_keysHeldDown.Contains(Keys.A) || _lst_keysHeldDown.Contains(Keys.Left);
            bool blnRightHeld = _lst_keysHeldDown.Contains(Keys.D) || _lst_keysHeldDown.Contains(Keys.Right);
            bool blnUpHeld = _lst_keysHeldDown.Contains(Keys.W) || _lst_keysHeldDown.Contains(Keys.Up);
            bool blnDownHeld = _lst_keysHeldDown.Contains(Keys.S) || _lst_keysHeldDown.Contains(Keys.Down);

            // Create movement-related int variables
            int intMoveX = 0;
            int intMoveY = 0;

            // Increment/decrement the movement-related int variables based off of the boolean variables
            if (blnLeftHeld)
            {
                intMoveX -= 1;
            }

            if (blnRightHeld)
            {
                intMoveX += 1;
            }

            if (blnUpHeld)
            {
                intMoveY -= 1;
            }

            if (blnDownHeld)
            {
                intMoveY += 1;
            }

            // Multiple the movement-related int variables by the game speed
            intMoveX *= GAMESPEED;
            intMoveY *= GAMESPEED;

            // Move the player
            _player.Move(intMoveX, intMoveY);


            _player.Update(interval);
        }

        // M�thode appel�e � chaque frame
        private void NewFrame(object sender, EventArgs e)
        {
            this.Update(ticker.Interval);
            this.Render();
        }

        private void ShootMeUp_KeyDown(object sender, KeyEventArgs e)
        {
            // Add the key to the list if it's not already in there
            if (!_lst_keysHeldDown.Contains(e.KeyCode))
            {
                _lst_keysHeldDown.Add(e.KeyCode);
            }
        }

        private void ShootMeUp_KeyUp(object sender, KeyEventArgs e)
        {
            // Remove the key from the list if it's in there
            if (_lst_keysHeldDown.Contains(e.KeyCode))
            {
                _lst_keysHeldDown.Remove(e.KeyCode);
            }
        }

        private void ShootMeUp_Load(object sender, EventArgs e)
        {

        }

        private void ShootMeUp_MouseClick(object sender, MouseEventArgs e)
        {

        }
    }
}